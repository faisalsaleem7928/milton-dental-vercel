import type { Metadata } from "next";
import ContactPageContent from "./ContactPageContent";
import { generateBreadcrumbSchema } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Contact Milton Dental Clinic | Book Appointment | (905) 876-4488",
  description: "Contact Milton Dental Clinic at 342 Bronte St. S Unit 1, Milton, ON. Book your dental appointment online or call (905) 876-4488. Open Monday-Saturday.",
  keywords: ["Milton dental clinic phone number", "book dentist appointment Milton", "Milton dentist address", "dental clinic Milton contact"],
  alternates: { canonical: "https://www.miltondentalclinic.com/contact" },
};

export default function ContactPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(generateBreadcrumbSchema([
            { name: "Home", url: "/" },
            { name: "Contact", url: "/contact" },
          ])),
        }}
      />
      <ContactPageContent />
    </>
  );
}
