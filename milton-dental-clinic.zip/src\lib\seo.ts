import { siteConfig } from "@/config/site";
import type { FAQ, BlogPost } from "@/types";

export function generateLocalBusinessSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Dentist",
    name: siteConfig.name,
    description: siteConfig.description,
    url: siteConfig.domain,
    telephone: siteConfig.phone,
    email: siteConfig.email,
    address: {
      "@type": "PostalAddress",
      streetAddress: siteConfig.address.street,
      addressLocality: siteConfig.address.city,
      addressRegion: siteConfig.address.state,
      postalCode: siteConfig.address.zip,
      addressCountry: siteConfig.address.country,
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: siteConfig.address.lat,
      longitude: siteConfig.address.lng,
    },
    openingHoursSpecification: siteConfig.hours
      .filter((h) => h.open !== "Closed")
      .map((h) => ({
        "@type": "OpeningHoursSpecification",
        dayOfWeek: h.day,
        opens: h.open,
        closes: h.close,
      })),
    image: `${siteConfig.domain}${siteConfig.ogImage}`,
    priceRange: "$$",
    sameAs: Object.values(siteConfig.socials).filter(Boolean),
  };
}

export function generateFAQSchema(faqs: FAQ[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };
}

export function generateArticleSchema(post: BlogPost) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.excerpt,
    image: post.featuredImage,
    datePublished: post.date,
    author: {
      "@type": "Person",
      name: post.author,
    },
    publisher: {
      "@type": "Organization",
      name: siteConfig.name,
      url: siteConfig.domain,
    },
  };
}

export function generateBreadcrumbSchema(
  items: { name: string; url: string }[]
) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: `${siteConfig.domain}${item.url}`,
    })),
  };
}

export function generateServiceSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "MedicalBusiness",
    "@id": "https://www.miltondentalclinic.com/#dentist",
    name: siteConfig.name,
    medicalSpecialty: [
      "General Dentistry",
      "Cosmetic Dentistry",
      "Emergency Dentistry",
      "Pediatric Dentistry",
      "Orthodontics",
      "Periodontics"
    ],
    availableService: [
      { "@type": "MedicalProcedure", name: "Dental Cleaning and Examination" },
      { "@type": "MedicalProcedure", name: "Teeth Whitening" },
      { "@type": "MedicalProcedure", name: "Dental Implants" },
      { "@type": "MedicalProcedure", name: "Invisalign" },
      { "@type": "MedicalProcedure", name: "Root Canal Therapy" },
      { "@type": "MedicalProcedure", name: "Dental Crowns and Bridges" },
      { "@type": "MedicalProcedure", name: "Emergency Dental Care" },
      { "@type": "MedicalProcedure", name: "Pediatric Dentistry" },
    ],
    areaServed: [
      { "@type": "City", name: "Milton", containedInPlace: { "@type": "State", name: "Ontario" } },
      { "@type": "City", name: "Oakville" },
      { "@type": "City", name: "Burlington" },
      { "@type": "City", name: "Georgetown" },
      { "@type": "City", name: "Halton Hills" },
    ],
    hasMap: siteConfig.address.googleMapsUrl,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: "4.9",
      reviewCount: "150",
      bestRating: "5"
    }
  };
}

export function generatePersonSchema(doctor: { name: string; credentials: string; description: string }) {
  return {
    "@context": "https://schema.org",
    "@type": "Dentist",
    name: doctor.name,
    description: doctor.description,
    jobTitle: doctor.credentials,
    worksFor: {
      "@type": "Organization",
      name: siteConfig.name,
      url: siteConfig.domain,
    },
    address: {
      "@type": "PostalAddress",
      streetAddress: siteConfig.address.street,
      addressLocality: siteConfig.address.city,
      addressRegion: siteConfig.address.state,
      postalCode: siteConfig.address.zip,
      addressCountry: siteConfig.address.country,
    },
  };
}
