import type { Metadata } from "next";
import AboutPageContent from "./AboutPageContent";
import { generateBreadcrumbSchema } from "@/lib/seo";

export const metadata: Metadata = {
  title: "About Us | Milton Dental Clinic - Meet Dr. Zoha Anjum & Team",
  description: "About Us - At the heart of our practice is a commitment to gentle, trauma-informed, and culturally sensitive dental care. We believe in practicing with integrity and honesty, ensuring that every patient feels respected and fully informed. We are dedicated to improving dental access for all, actively engaging with our community to promote oral health education and support.",
  keywords: ["Dr Zoha Anjum Milton", "Milton dentist team", "about Milton Dental Clinic", "dentist Milton Ontario", "Dr Sherief Mohamed", "Dr Muhammad Yasin Anjum"],
  alternates: { canonical: "https://www.miltondentalclinic.com/about" },
};

export default function AboutPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(generateBreadcrumbSchema([
            { name: "Home", url: "/" },
            { name: "About Us", url: "/about" },
          ])),
        }}
      />
      <AboutPageContent />
    </>
  );
}
