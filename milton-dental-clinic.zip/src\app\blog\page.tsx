import type { Metadata } from "next";
import BlogPageContent from "./BlogPageContent";
import { generateBreadcrumbSchema } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Dental Health Blog | Tips & Advice | Milton Dental Clinic",
  description: "Read expert dental health articles, oral care tips, and the latest news from Milton Dental Clinic. Stay informed about preventive dentistry, oral health during pregnancy, and more.",
  keywords: ["dental health blog", "oral care tips Milton", "dental advice", "Milton dental clinic blog"],
  alternates: { canonical: "https://www.miltondentalclinic.com/blog" },
};

export default function BlogPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(generateBreadcrumbSchema([
            { name: "Home", url: "/" },
            { name: "Blog", url: "/blog" },
          ])),
        }}
      />
      <BlogPageContent />
    </>
  );
}
