(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,44498,e=>{"use strict";var t=e.i(71645);function a(){let e=(0,t.useRef)(null);return(0,t.useEffect)(()=>{let t=e.current;if(!t)return;let a=t.querySelectorAll(".animate-on-scroll, .animate-slide-left, .animate-slide-right, .animate-scale-in, .animate-blur-in, .heading-line, .stagger-children"),n=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&(e.target.classList.add("animated"),n.unobserve(e.target))})},{threshold:.1,rootMargin:"0px 0px -40px 0px"});return a.forEach(e=>n.observe(e)),()=>n.disconnect()},[]),e}e.s(["useScrollAnimation",()=>a])},30604,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(22016),i=e.i(44498);let o={mid:{heading:"Transform Your Smile Today",text:"Embark on your journey towards a healthier, brighter smile with our expert dental team. Your ideal smile awaits!",buttons:[{label:"Book Appointment",href:"/contact",variant:"solid"}],bgImage:"/miltondentalclinic/images/services/specialized-treatment.webp",overlay:"bg-gradient-to-r from-primary/90 via-primary/80 to-dark/70"},bottom:{heading:"Take the first step towards a healthier smile",text:"Contact us today to schedule your appointment and start your journey towards optimal oral health with Milton Dental Clinic.",buttons:[{label:"Book Appointment",href:"/contact",variant:"solid"},{label:"(905) 876-4488",href:"tel:9058764488",variant:"outline"}],bgImage:"/miltondentalclinic/images/hero/hero-bg.webp",overlay:"bg-gradient-to-r from-dark/90 via-dark/80 to-primary/60"}};function s({variant:e}){let s=(0,i.useScrollAnimation)(),{heading:r,text:l,buttons:d,bgImage:c,overlay:m}=o[e];return(0,t.jsxs)("section",{className:"relative w-full overflow-hidden",children:[(0,t.jsx)(a.default,{src:c,alt:"",fill:!0,className:"object-cover",sizes:"100vw"}),(0,t.jsx)("div",{className:`absolute inset-0 ${m}`}),(0,t.jsxs)("div",{ref:s,className:"relative z-10 max-w-4xl mx-auto px-4 sm:px-6 py-20 md:py-28 text-center",children:[(0,t.jsx)("h2",{className:"animate-on-scroll font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight",children:r}),(0,t.jsx)("p",{className:"animate-on-scroll delay-1 mt-5 text-base sm:text-lg text-white/85 max-w-2xl mx-auto leading-relaxed",children:l}),(0,t.jsx)("div",{className:"animate-on-scroll delay-2 mt-9 flex flex-col sm:flex-row items-center justify-center gap-4",children:d.map(e=>"solid"===e.variant?(0,t.jsx)(n.default,{href:e.href,className:"magnetic-btn pulse-ring inline-flex items-center px-7 py-3 bg-white text-dark text-sm font-semibold rounded-md hover:bg-gray-100 transition-colors shadow-lg",children:e.label},e.label):(0,t.jsx)("a",{href:e.href,className:"magnetic-btn inline-flex items-center px-7 py-3 border-2 border-white text-white text-sm font-semibold rounded-md hover:bg-white/10 transition-colors",children:e.label},e.label))})]})]})}e.s(["default",()=>s])},36468,e=>{"use strict";let t=[{title:"Improving ‘Community Smiles’ through patient education and health promotion",excerpt:"The first-ever Canadian Oral Health Survey (COHS), conducted from November…",slug:"improving-community-smiles",image:"/miltondentalclinic/images/blog/community-smiles.jpg",date:"2025-01-15",content:`The first-ever Canadian Oral Health Survey (COHS), conducted from November 2023 to March 2024, showed how poor oral health can impact everyday life, including eating, working, or going to school, and provides important baseline data as Canada rolls out the new Canadian Dental Care Plan.

At The Community Smiles Project, our group of dentists, public health professionals, and educators is passionate about oral health education and improving access to dental care in Toronto. We aim to equip our communities with knowledge and resources to care for their oral health through community outreach, oral health education, and oral disease prevention delivered in an accessible, culturally inclusive, and evidence-based way.

## Why Patient Education Matters

Oral health is often overlooked in broader health discussions, yet it plays a significant role in our overall well-being. Over 1 in 4 Canadians report tooth pain or avoid certain foods because of dental problems, with seniors, people without dental insurance, and those with disabilities being most affected.

Through community outreach programs, we deliver oral health workshops at schools, community events, and cultural organizations. Our approach is rooted in making information accessible and culturally inclusive, ensuring that every community member can benefit from our educational efforts.

## Our Approach

We believe that prevention is the best medicine. By educating communities about proper oral hygiene practices, nutrition's impact on dental health, and the importance of regular dental visits, we can help reduce the burden of oral disease.

Our team of young professionals is committed to improving access to oral health education through research and content creation, translating complex dental health information into easy-to-understand resources for the general public.

## Get Involved

If you're a community organization or leader interested in collaborating with The Community Smiles Project, we welcome your inquiries. Together, we can improve access to oral health education and dental services across the Greater Toronto Area.`},{title:"Oral health in pregnancy: Understanding risks, prevention, and safe dental care",excerpt:"Introduction Pregnancy is a time of a complex hormonal and…",slug:"oral-health-in-pregnancy-risks-prevention",image:"/miltondentalclinic/images/blog/oral-health-pregnancy.jpg",date:"2025-01-10",content:`## Introduction

Pregnancy is a time of complex hormonal and physiological changes that can significantly impact oral health. Understanding these risks and knowing how to maintain good dental hygiene during pregnancy is essential for both the mother's and baby's well-being.

## How Pregnancy Affects Oral Health

During pregnancy, hormonal changes\u2014particularly increased levels of estrogen and progesterone\u2014can affect the way your body responds to plaque. This can lead to several oral health concerns:

- **Pregnancy Gingivitis:** Swollen, tender gums that bleed easily, affecting up to 75% of pregnant women
- **Increased Risk of Tooth Decay:** Morning sickness and changes in eating habits can expose teeth to more acid
- **Pregnancy Tumors:** Non-cancerous growths on the gums that typically appear during the second trimester
- **Loose Teeth:** Elevated levels of progesterone and estrogen can affect the ligaments and bone supporting the teeth

## Prevention and Safe Dental Care

Maintaining good oral health during pregnancy is not only safe but highly recommended. Here are key prevention strategies:

1. **Continue Regular Dental Visits:** Routine cleanings and exams are safe during pregnancy
2. **Practice Good Oral Hygiene:** Brush twice daily with fluoride toothpaste and floss daily
3. **Manage Morning Sickness:** Rinse with baking soda and water after vomiting to neutralize acids
4. **Eat a Balanced Diet:** Limit sugary snacks and ensure adequate calcium and vitamin D intake
5. **Communicate with Your Dentist:** Inform them about your pregnancy and any medications you're taking

## When to Seek Dental Care

Don't delay dental treatment during pregnancy. If you experience tooth pain, swelling, or bleeding gums, contact your dentist promptly. Most dental procedures, including fillings and root canals, can be safely performed during pregnancy, particularly during the second trimester.

At Milton Dental Clinic, we provide safe, compassionate dental care for expectant mothers. Contact us at (905) 876-4488 to schedule your appointment.`},{title:"Oral Health During Pregnancy in Milton",excerpt:"Pregnancy is an exciting time filled with change. Along with…",slug:"oral-health-during-pregnancy-in-milton",image:"/miltondentalclinic/images/blog/pregnancy-milton.jpg",date:"2025-01-05",content:`Pregnancy is an exciting time filled with change. Along with the many physical changes happening in your body, your oral health needs extra attention too. At Milton Dental Clinic, we understand the unique dental needs of expectant mothers and are here to support you every step of the way.

## Why Oral Health Matters During Pregnancy

Your oral health is closely connected to your overall health and your baby's development. Research has shown links between gum disease and premature birth, low birth weight, and other complications. Taking care of your teeth and gums during pregnancy is one of the best things you can do for yourself and your baby.

## Common Dental Concerns During Pregnancy

Many pregnant women in Milton experience:

- **Bleeding or Swollen Gums:** Hormonal changes can make your gums more sensitive to plaque
- **Increased Cavity Risk:** Cravings for sugary foods and morning sickness can increase the risk of tooth decay
- **Dry Mouth:** Some pregnant women experience decreased saliva production
- **Enamel Erosion:** Frequent vomiting from morning sickness can erode tooth enamel

## Tips for Maintaining Oral Health

- Brush your teeth twice a day with a soft-bristled toothbrush
- Floss daily to remove plaque between teeth
- Use an antimicrobial mouth rinse if recommended by your dentist
- If you experience morning sickness, rinse your mouth with water or a baking soda solution
- Eat calcium-rich foods to support your baby's developing teeth and bones
- Stay hydrated throughout the day

## Dental Visits During Pregnancy

Regular dental check-ups are safe and important during pregnancy. The second trimester is often considered the most comfortable time for dental treatment. At Milton Dental Clinic, Dr. Zoha Anjum and our team provide gentle, pregnancy-safe dental care.

Contact us at (905) 876-4488 to schedule your prenatal dental visit at our Milton office.`},{title:"Preventive Dentistry in Milton for Healthier Smiles",excerpt:"At Milton Dental Clinic, we believe that strong smiles begin…",slug:"preventive-dentistry-in-milton",image:"/miltondentalclinic/images/blog/preventive-dentistry.jpg",date:"2024-12-20",content:`At Milton Dental Clinic, we believe that strong smiles begin with prevention. Preventive dentistry is the foundation of good oral health, helping you avoid costly and complex treatments down the road. Our team is dedicated to keeping your smile healthy through regular care and education.

## What Is Preventive Dentistry?

Preventive dentistry focuses on maintaining oral health through regular check-ups, cleanings, and good daily habits. It's about stopping dental problems before they start, rather than treating them after they develop.

## Our Preventive Services

At Milton Dental Clinic, we offer a comprehensive range of preventive services:

- **Regular Dental Exams:** Thorough examinations including TMJ and gum assessments
- **Professional Cleanings:** Scaling, polishing, and fluoride treatments
- **Oral Cancer Screenings:** Early detection of any abnormalities
- **Digital X-Rays:** Advanced imaging with minimal radiation exposure
- **Dental Sealants:** Protective coatings for cavity-prone teeth
- **Custom Mouthguards:** Protection for sports and nighttime grinding

## The Benefits of Preventive Care

Investing in preventive dentistry offers numerous benefits:

1. **Early Detection:** Catching problems when they're small and easier to treat
2. **Cost Savings:** Prevention is far less expensive than treatment
3. **Better Overall Health:** Oral health is connected to heart health, diabetes management, and more
4. **Preserved Natural Teeth:** Keep your natural smile for a lifetime
5. **Fresh Breath and Confidence:** Regular cleanings keep your smile bright

## Building Good Habits at Home

Preventive care extends beyond the dental office. We recommend:

- Brushing twice daily with fluoride toothpaste for at least two minutes
- Flossing daily to clean between teeth where your brush can't reach
- Limiting sugary and acidic foods and drinks
- Drinking plenty of water throughout the day
- Replacing your toothbrush every three to four months

## Schedule Your Preventive Visit

Don't wait for a problem to see the dentist. Schedule your preventive care appointment at Milton Dental Clinic today. Call us at (905) 876-4488 or visit our contact page to book online.`},{title:"Why Regular Dental Visits Matter for Milton Families in Milton",excerpt:"Pregnancy is an exciting time filled with change. Your mouth…",slug:"why-regular-dental-visits-matter",image:"/miltondentalclinic/images/blog/regular-visits.jpg",date:"2024-12-15",content:`Regular dental visits are one of the most important things you can do for your family's oral health. At Milton Dental Clinic, we recommend that every family member\u2014from toddlers to grandparents\u2014visit the dentist at least twice a year for check-ups and cleanings.

## Why Twice a Year?

Even if your teeth feel fine, regular dental visits are essential because:

- **Early Detection:** Many dental problems, including cavities and gum disease, don't cause pain in their early stages. Regular check-ups allow your dentist to catch issues before they become serious.
- **Professional Cleaning:** Even with excellent brushing and flossing, plaque and tartar can build up in hard-to-reach areas. Professional cleanings remove this buildup and help prevent cavities and gum disease.
- **Oral Cancer Screening:** Your dentist checks for signs of oral cancer at every visit, which is crucial for early detection and treatment.

## Benefits for Children

Starting dental visits early sets your children up for a lifetime of good oral health:

- Familiarizes them with the dental office, reducing anxiety
- Monitors the development of their teeth and jaw
- Applies preventive treatments like sealants and fluoride
- Teaches proper brushing and flossing techniques
- Identifies orthodontic needs early

## Benefits for Adults and Seniors

Regular visits are equally important as we age:

- Monitoring existing dental work (fillings, crowns, bridges)
- Managing gum disease, which becomes more common with age
- Screening for conditions linked to oral health, such as diabetes and heart disease
- Addressing dry mouth, which can be a side effect of many medications
- Maintaining dentures and other prosthetics

## Making Dental Visits a Family Affair

At Milton Dental Clinic, we welcome patients of all ages. Our team, led by Dr. Zoha Anjum, creates a comfortable and welcoming environment for the whole family. We're proud to serve Milton families with compassionate, comprehensive dental care.

Book your family's next dental visit today. Call (905) 876-4488 or visit us at 342 Bronte St. S Unit 1, Milton, ON.`},{title:"Dental Check-Up Process: What to Expect at Your Next Appointment",excerpt:"If you’re unsure about what to expect during your next…",slug:"dental-check-up-process",image:null,date:"2024-12-10",content:`If you're unsure about what to expect during your next dental visit, understanding the process can help ease any anxiety. At Milton Dental Clinic, we strive to make every appointment as comfortable and transparent as possible.

## What Happens During a Dental Check-Up?

A typical dental check-up at our Milton clinic includes several important steps:

### 1. Medical History Review

We'll review your medical history and any changes since your last visit. This includes new medications, health conditions, or concerns you may have about your oral health.

### 2. Digital X-Rays

If needed, we'll take digital X-rays to get a detailed look at your teeth, jawbone, and surrounding structures. Digital X-rays use significantly less radiation than traditional film X-rays and provide instant, high-quality images.

### 3. Comprehensive Oral Examination

Your dentist will carefully examine:

- Each tooth for signs of decay, cracks, or damage
- Your gums for signs of gum disease
- Your bite and jaw alignment
- Previous dental work (fillings, crowns, etc.)
- Soft tissues of the mouth for any abnormalities
- TMJ (jaw joint) function

### 4. Oral Cancer Screening

As part of every check-up, we screen for signs of oral cancer by examining your lips, tongue, throat, tissues, and gums.

### 5. Professional Cleaning

Our dental hygienist will:

- Remove plaque and tartar buildup
- Polish your teeth to remove surface stains
- Floss between all teeth
- Apply fluoride treatment if recommended

### 6. Discussion and Treatment Plan

After your examination, your dentist will discuss findings with you, answer any questions, and recommend any necessary treatments. We believe in empowering our patients to make informed decisions about their dental care.

## How Often Should You Visit?

We recommend visiting every six months for routine check-ups and cleanings. However, some patients may need more frequent visits depending on their oral health needs.

Schedule your next check-up at Milton Dental Clinic by calling (905) 876-4488.`},{title:"10 Signs You Need to See a Dentist ASAP",excerpt:"Are you experiencing pain, bleeding, or unusual changes in your…",slug:"10-signs-you-need-to-see-a-dentist",image:null,date:"2024-12-05",content:`Are you experiencing pain, bleeding, or unusual changes in your mouth? While some dental issues can wait for your next scheduled appointment, certain signs indicate you should see a dentist as soon as possible.

## 1. Persistent Toothache

A toothache that doesn't go away could indicate a cavity, infection, or abscess. Don't try to tough it out\u2014seek professional care to prevent the problem from worsening.

## 2. Bleeding Gums

While occasional bleeding during flossing may not be alarming, persistent bleeding gums can be a sign of gum disease. Early treatment can prevent more serious complications.

## 3. Swollen or Red Gums

Inflammation in your gums often signals gingivitis or periodontitis. Left untreated, gum disease can lead to tooth loss and has been linked to heart disease and diabetes.

## 4. Sensitivity to Hot or Cold

If drinking hot coffee or eating ice cream causes sharp pain, you may have a cavity, worn enamel, or an exposed tooth root that needs attention.

## 5. Loose or Shifting Teeth

Adult teeth should not feel loose. If you notice any movement, it could indicate advanced gum disease or bone loss.

## 6. Persistent Bad Breath

Chronic bad breath (halitosis) that doesn't improve with brushing and flossing may indicate an underlying dental or health issue.

## 7. White or Dark Spots on Teeth

White spots can be early signs of decay, while dark spots may indicate a cavity that needs treatment before it grows larger.

## 8. Jaw Pain or Clicking

Pain, popping, or clicking in your jaw could signal TMJ disorder, which can worsen without proper treatment.

## 9. Mouth Sores That Won't Heal

A sore that persists for more than two weeks should be evaluated, as it could be a sign of oral cancer or another condition requiring treatment.

## 10. Broken or Chipped Tooth

Even if it doesn't hurt, a broken or chipped tooth can worsen over time and become vulnerable to infection.

## Don't Wait\u2014We're Here to Help

If you're experiencing any of these signs, contact Milton Dental Clinic right away at (905) 876-4488. Our team provides prompt, compassionate care to address your dental concerns.`},{title:"Top 7 Benefits of a Professional Teeth Cleaning",excerpt:"Your smile is one of your most powerful assets—and keeping…",slug:"top-7-benefits-of-professional-teeth-cleaning",image:null,date:"2024-11-28",content:`Your smile is one of your most powerful assets\u2014and keeping it healthy goes beyond brushing and flossing at home. Professional teeth cleanings are a cornerstone of preventive dental care, offering benefits that extend far beyond a brighter smile.

## 1. Prevents Gum Disease

Gum disease is one of the leading causes of tooth loss in adults. Professional cleanings remove plaque and tartar buildup along and below the gum line, significantly reducing your risk of developing gingivitis and periodontitis.

## 2. Early Detection of Dental Problems

During your cleaning appointment, your dental team examines your mouth for early signs of cavities, broken fillings, gum disease, and even oral cancer. Catching these issues early means simpler, less expensive treatments.

## 3. Removes Stubborn Stains

Coffee, tea, wine, and certain foods can stain your teeth over time. Professional cleaning and polishing removes these surface stains, leaving your teeth looking brighter and cleaner.

## 4. Freshens Your Breath

Persistent bad breath is often caused by food particles and bacteria hiding in hard-to-reach places. A thorough professional cleaning eliminates these odor-causing culprits and gives you fresh, clean breath.

## 5. Protects Your Overall Health

Research has shown strong connections between oral health and overall health. Gum disease has been linked to heart disease, stroke, diabetes complications, and respiratory issues. Keeping your mouth healthy helps protect your whole body.

## 6. Saves Money in the Long Run

Prevention is always more affordable than treatment. Regular cleanings help you avoid costly procedures like root canals, crowns, and gum surgery by catching problems before they become serious.

## 7. Boosts Your Confidence

There's nothing quite like the feeling of a freshly cleaned smile. Professional cleanings give you the confidence to smile freely, knowing your teeth are healthy and looking their best.

## How Often Should You Get a Cleaning?

Most people benefit from professional cleanings every six months. However, if you have gum disease or other risk factors, your dentist may recommend more frequent visits.

## Schedule Your Cleaning Today

Ready to experience the benefits of a professional cleaning? Contact Milton Dental Clinic at (905) 876-4488 to book your appointment. Our gentle, experienced team is here to keep your smile healthy and bright.`}];e.s(["blogPosts",0,t])},35296,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(22016);function i(){return(0,t.jsxs)("section",{className:"relative w-full h-screen flex items-center justify-center overflow-hidden",children:[(0,t.jsx)(a.default,{src:"/miltondentalclinic/images/hero/hero-bg.webp",alt:"Milton Dental Clinic",fill:!0,priority:!0,className:"object-cover object-center scale-105 animate-[heroZoom_20s_ease-in-out_infinite_alternate]",sizes:"100vw"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-b from-[#1a2836]/70 via-[#1a2836]/50 to-[#1a2836]/80"}),(0,t.jsxs)("div",{className:"relative z-10 text-center max-w-5xl mx-auto px-4 sm:px-6",children:[(0,t.jsxs)("h1",{className:"font-[family-name:var(--font-heading)] text-white leading-[1.15] tracking-tight",children:[(0,t.jsx)("span",{className:"block text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold italic opacity-0 animate-[heroFadeUp_0.8s_ease-out_0.2s_forwards]",children:"Caring for our community,"}),(0,t.jsx)("span",{className:"block text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold italic opacity-0 animate-[heroFadeUp_0.8s_ease-out_0.5s_forwards]",children:"one smile at a time."})]}),(0,t.jsx)("div",{className:"mt-6 mx-auto w-20 h-0.5 bg-white/40 opacity-0 animate-[heroFadeUp_0.6s_ease-out_0.9s_forwards]"}),(0,t.jsxs)("div",{className:"mt-10 sm:mt-12 flex flex-col sm:flex-row items-center justify-center gap-5 opacity-0 animate-[heroFadeUp_0.8s_ease-out_1.1s_forwards]",children:[(0,t.jsx)(n.default,{href:"/contact",className:"inline-flex items-center px-10 py-4 bg-[#0075C9] text-white text-base font-semibold rounded-md hover:bg-[#0063ab] transition-colors shadow-lg shadow-[#0075C9]/30",children:"Book Appointment"}),(0,t.jsx)("a",{href:"tel:9058764488",className:"inline-flex items-center px-10 py-4 border-2 border-white/80 text-white text-base font-semibold rounded-md hover:bg-white/10 transition-colors",children:"(905) 876-4488"})]})]}),(0,t.jsx)("div",{className:"absolute bottom-8 left-1/2 -translate-x-1/2 opacity-0 animate-[heroFadeUp_0.6s_ease-out_1.5s_forwards]",children:(0,t.jsx)("div",{className:"w-6 h-10 border-2 border-white/40 rounded-full flex justify-center",children:(0,t.jsx)("div",{className:"w-1 h-2.5 bg-white/60 rounded-full mt-2 animate-[scrollBounce_2s_ease-in-out_infinite]"})})})]})}e.s(["default",()=>i])},16476,e=>{"use strict";var t=e.i(43476);function a({children:e,className:a="",id:n}){return(0,t.jsx)("section",{id:n,className:`py-16 md:py-24 overflow-hidden ${a}`,children:(0,t.jsx)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:e})})}e.s(["default",()=>a])},29060,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(16476),i=e.i(44498);let o=[{title:"Preventive and Diagnostic Care",image:"/miltondentalclinic/images/services/preventive-care.webp",description:"We focus on keeping your smile healthy with thorough exams, including TMJ and gum assessments, oral cancer screenings, and digital X-rays. Our preventive services -- scaling, polishing, fluoride treatments, and dental sealants -- help stop problems before they start, while our oral health education and diet counselling empower you to care for your smile every day."},{title:"Restorative and Cosmetic Dentistry",image:"/miltondentalclinic/images/services/restorative-cosmetic.webp",description:"From fillings, crowns, and bridges to whitening and bonding, we restore and enhance your teeth with natural-looking results. Whether you need simple repairs or a complete smile makeover, we combine skill and artistry to help you look and feel your best."},{title:"Specialized Treatment and Orthodontics",image:"/miltondentalclinic/images/services/specialized-treatment.webp",description:"Our team provides advanced care, including Invisalign, retainers, root canals, wisdom tooth extractions, implants, and full or partial dentures. We take pride in offering comprehensive solutions for every stage of your dental health, all under one roof."}];function s(){let e=(0,i.useScrollAnimation)();return(0,t.jsx)(n.default,{id:"services",children:(0,t.jsxs)("div",{ref:e,children:[(0,t.jsxs)("div",{className:"text-center mb-12 md:mb-16 animate-blur-in",children:[(0,t.jsx)("h2",{className:"font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-dark",children:"Comprehensive Dental Services"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-dark/70 max-w-2xl mx-auto",children:"Explore our range of high-quality dental treatments and diagnostic services for the whole family."})]}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-8",children:o.map((e,n)=>(0,t.jsxs)("div",{className:`animate-on-scroll delay-${n+1} glow-card group bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300`,children:[(0,t.jsx)("div",{className:"relative h-56 sm:h-64 overflow-hidden",children:(0,t.jsx)(a.default,{src:e.image,alt:e.title,fill:!0,className:"object-cover transition-transform duration-500 group-hover:scale-105",sizes:"(max-width: 768px) 100vw, 33vw"})}),(0,t.jsxs)("div",{className:"p-6",children:[(0,t.jsx)("h3",{className:"font-[family-name:var(--font-heading)] text-xl font-bold text-dark mb-3",children:e.title}),(0,t.jsx)("p",{className:"text-dark/70 leading-relaxed text-sm",children:e.description})]})]},e.title))})]})})}e.s(["default",()=>s])},94155,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(44498);let i=[{src:"/miltondentalclinic/images/members/member-2.png",alt:"Ontario Dental Association"},{src:"/miltondentalclinic/images/members/member-4.png",alt:"Royal College of Dental Surgeons of Ontario"},{src:"/miltondentalclinic/images/members/member-3.png",alt:"Milton Chamber of Commerce"},{src:"/miltondentalclinic/images/members/member-1.png",alt:"Academy of General Dentistry"}];function o(){let e=(0,n.useScrollAnimation)();return(0,t.jsx)("section",{className:"py-16 md:py-24 bg-black",children:(0,t.jsxs)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",ref:e,children:[(0,t.jsx)("h2",{className:"animate-on-scroll font-[family-name:var(--font-heading)] text-2xl sm:text-3xl md:text-4xl font-bold text-white text-center mb-14",children:"Proud Members Of"}),(0,t.jsx)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-10 md:gap-16 items-center justify-items-center",children:i.map((e,n)=>(0,t.jsx)("div",{className:`animate-on-scroll delay-${n+1} relative w-full h-16 md:h-20 hover:opacity-80 transition-opacity duration-300`,children:(0,t.jsx)(a.default,{src:e.src,alt:e.alt,fill:!0,className:"object-contain",sizes:"250px"})},e.src))})]})})}e.s(["default",()=>o])},95738,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(22016),i=e.i(44498),o=e.i(16476);function s(){let e=(0,i.useScrollAnimation)();return(0,t.jsx)(o.default,{id:"about",children:(0,t.jsxs)("div",{ref:e,className:"grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center",children:[(0,t.jsxs)("div",{className:"animate-slide-left animate-float relative h-[400px] sm:h-[480px]",children:[(0,t.jsx)("div",{className:"absolute top-0 left-0 w-[65%] h-[75%] rounded-2xl overflow-hidden shadow-xl",children:(0,t.jsx)(a.default,{src:"/miltondentalclinic/images/about/about-1.webp",alt:"Milton Dental Clinic team",fill:!0,className:"object-cover",sizes:"(max-width: 1024px) 65vw, 30vw"})}),(0,t.jsx)("div",{className:"absolute bottom-0 right-0 w-[60%] h-[65%] rounded-2xl overflow-hidden shadow-xl border-4 border-white",children:(0,t.jsx)(a.default,{src:"/miltondentalclinic/images/about/about-2.webp",alt:"Milton Dental Clinic office",fill:!0,className:"object-cover",sizes:"(max-width: 1024px) 60vw, 28vw"})})]}),(0,t.jsxs)("div",{className:"animate-slide-right",children:[(0,t.jsx)("h2",{className:"font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-dark mb-6",children:"About Us"}),(0,t.jsx)("p",{className:"text-dark/70 leading-relaxed mb-4 text-base sm:text-lg",children:"At the heart of our practice is a commitment to gentle, trauma-informed, and culturally sensitive dental care. We believe in practicing with integrity and honesty, ensuring that every patient feels respected and fully informed."}),(0,t.jsx)("p",{className:"text-dark/70 leading-relaxed mb-8 text-base sm:text-lg",children:"We are dedicated to improving dental access for all, actively engaging with our community to promote oral health education and support. Above all, we focus on prevention, helping our patients maintain healthy smiles for life."}),(0,t.jsx)(n.default,{href:"/about",className:"magnetic-btn inline-flex items-center px-8 py-3.5 bg-primary text-white font-semibold rounded-full hover:bg-primary/90 transition-colors shadow-md shadow-primary/20 text-base",children:"Read More"})]})]})})}e.s(["default",()=>s])},1004,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(22016),i=e.i(16476),o=e.i(44498);let s=e.i(36468).blogPosts.slice(0,5);function r(){let e=(0,o.useScrollAnimation)();return(0,t.jsx)(i.default,{id:"blog",children:(0,t.jsxs)("div",{ref:e,children:[(0,t.jsxs)("div",{className:"text-center mb-12 md:mb-16 animate-blur-in",children:[(0,t.jsx)("h2",{className:"font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-dark",children:"Brush Up on Dental Health: Insights, Tips & Tricks"}),(0,t.jsx)("span",{className:"mt-4 mx-auto w-20 heading-line"})]}),(0,t.jsx)("div",{className:"stagger-children flex gap-5 overflow-x-auto pb-4 snap-x snap-mandatory md:grid md:grid-cols-3 lg:grid-cols-5 md:overflow-x-visible md:pb-0 scrollbar-hide",children:s.map((e,i)=>(0,t.jsx)("div",{className:`animate-on-scroll delay-${Math.min(i+1,5)} min-w-[260px] md:min-w-0 snap-start flex-shrink-0 md:flex-shrink`,children:(0,t.jsxs)(n.default,{href:`/blog/${e.slug}`,className:"group block rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1",children:[(0,t.jsxs)("div",{className:"relative h-48 overflow-hidden",children:[e.image?(0,t.jsx)(a.default,{src:e.image,alt:e.title,fill:!0,className:"object-cover transition-transform duration-500 group-hover:scale-110",sizes:"(max-width: 768px) 260px, (max-width: 1024px) 33vw, 20vw"}):(0,t.jsx)("div",{className:"w-full h-full bg-gradient-to-br from-[#0075C9]/15 to-[#0075C9]/5 flex items-center justify-center",children:(0,t.jsx)("svg",{className:"w-12 h-12 text-[#0075C9]/20",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:1,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5M6 7.5h3v3H6V7.5z"})})}),(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"}),(0,t.jsx)("div",{className:"absolute bottom-0 left-0 right-0 p-4",children:(0,t.jsx)("h3",{className:"text-white text-sm font-bold leading-snug line-clamp-3 drop-shadow-lg",children:e.title})})]}),(0,t.jsxs)("div",{className:"bg-white px-4 py-3 flex items-center justify-between",children:[(0,t.jsx)("span",{className:"text-xs font-semibold text-primary",children:"Read More"}),(0,t.jsx)("span",{className:"text-primary text-sm",children:"→"})]})]})},e.slug))})]})})}e.s(["default",()=>r])},37528,e=>{"use strict";var t=e.i(43476),a=e.i(57688);let n=(0,e.i(75254).default)("quote",[["path",{d:"M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"rib7q0"}],["path",{d:"M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",key:"1ymkrd"}]]);var i=e.i(16476),o=e.i(44498);let s=[{quote:"I recently visited Dr. Anjum and was extremely impressed. She took the time to get to know me personally, which made me feel comfortable and valued. Dr. Anjum thoroughly explained the treatment plan and provided all the information I needed to make an informed decision about my dental care. I appreciated how she empowered me to choose the best option for my needs.",name:"Ayak Wel"},{quote:"Dr Anjum and her team are the best you can get in Canadian dentistry -- professional and very punctual. My favourite part about her practice is that she is very accommodating to my schedule (open past 5pm) and she also explains dental information very clearly. So happy to have found this dental clinic!",name:"Amna Zulfiqar"},{quote:"Went for my first appointment with Dr. Zoha Anjum and honestly had a great time! Super painless cleaning and she really reassured me regarding all concerns in my care. 10/10 highly recommend!",name:"Shifa Minhas"}];function r(){let e=(0,o.useScrollAnimation)();return(0,t.jsx)(i.default,{id:"testimonials",children:(0,t.jsxs)("div",{ref:e,children:[(0,t.jsx)("div",{className:"text-center mb-12 md:mb-16 animate-blur-in",children:(0,t.jsx)("h2",{className:"font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-dark",children:"Thrilled Patients Say"})}),(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-8",children:s.map((e,i)=>(0,t.jsxs)("div",{className:`animate-on-scroll delay-${i+1} glow-card bg-white rounded-2xl p-6 sm:p-8 shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col`,children:[(0,t.jsx)(n,{className:"w-10 h-10 text-primary/20 mb-4 flex-shrink-0"}),(0,t.jsxs)("p",{className:"text-dark/70 leading-relaxed text-sm sm:text-base flex-grow",children:["“",e.quote,"”"]}),(0,t.jsxs)("div",{className:"mt-6 flex items-center justify-between pt-4 border-t border-gray-100",children:[(0,t.jsx)("span",{className:"font-[family-name:var(--font-heading)] font-bold text-dark text-base",children:e.name}),(0,t.jsx)(a.default,{src:"/miltondentalclinic/images/icons/google.png",alt:"Google review",width:24,height:24,className:"w-6 h-6"})]})]},e.name))})]})})}e.s(["default",()=>r],37528)},91075,e=>{"use strict";var t=e.i(43476),a=e.i(57688),n=e.i(16476),i=e.i(44498);let o=["/miltondentalclinic/images/instagram/post-1.webp","/miltondentalclinic/images/instagram/post-2.webp","/miltondentalclinic/images/instagram/post-3.webp","/miltondentalclinic/images/instagram/post-4.webp"];function s(){let e=(0,i.useScrollAnimation)();return(0,t.jsx)(n.default,{id:"instagram",children:(0,t.jsxs)("div",{ref:e,children:[(0,t.jsx)("div",{className:"animate-on-scroll text-center mb-10",children:(0,t.jsxs)("div",{className:"flex items-center justify-center gap-4 mb-4",children:[(0,t.jsx)("div",{className:"relative w-16 h-16 rounded-full overflow-hidden ring-2 ring-primary/20",children:(0,t.jsx)(a.default,{src:"/miltondentalclinic/images/instagram/profile.webp",alt:"Milton Dental Clinic Instagram profile",fill:!0,className:"object-cover",sizes:"64px"})}),(0,t.jsxs)("div",{className:"text-left",children:[(0,t.jsx)("h3",{className:"font-[family-name:var(--font-heading)] text-lg font-bold text-dark",children:"@miltondentalclinic"}),(0,t.jsx)("p",{className:"text-dark/60 text-sm",children:"905.876.4488 | info@miltondentalclinic.com"})]})]})}),(0,t.jsx)("div",{className:"grid grid-cols-2 md:grid-cols-4 gap-4",children:o.map((e,n)=>(0,t.jsxs)("a",{href:"https://www.instagram.com/miltondentalclinic/",target:"_blank",rel:"noopener noreferrer",className:`animate-scale-in delay-${n+1} group relative aspect-square rounded-xl overflow-hidden`,children:[(0,t.jsx)(a.default,{src:e,alt:`Instagram post ${n+1}`,fill:!0,className:"object-cover transition-transform duration-500 group-hover:scale-110",sizes:"(max-width: 768px) 50vw, 25vw"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-dark/0 group-hover:bg-dark/40 transition-colors duration-300 flex items-center justify-center",children:(0,t.jsx)("svg",{className:"w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300",fill:"currentColor",viewBox:"0 0 24 24","aria-hidden":"true",children:(0,t.jsx)("path",{d:"M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"})})})]},e))}),(0,t.jsx)("div",{className:"animate-on-scroll delay-5 text-center mt-8",children:(0,t.jsx)("a",{href:"https://www.instagram.com/miltondentalclinic/",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center px-8 py-3.5 bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400 text-white font-semibold rounded-full hover:opacity-90 transition-opacity shadow-lg text-base",children:"Follow on Instagram"})})]})})}e.s(["default",()=>s])},21773,e=>{"use strict";var t=e.i(43476),a=e.i(71645),n=e.i(64659),i=e.i(16476),o=e.i(44498);let s=[{question:"What dental services does Milton Dental Clinic offer?",answer:"Milton Dental Clinic offers comprehensive dental services including preventive care (cleanings, exams, X-rays), cosmetic dentistry (whitening, veneers, bonding), restorative dentistry (fillings, crowns, bridges, implants), orthodontics (Invisalign, retainers), emergency dental care, pediatric dentistry, root canal therapy, wisdom tooth extraction, and periodontics."},{question:"Does Milton Dental Clinic accept walk-in emergency patients?",answer:"Yes, Milton Dental Clinic offers same-day emergency dental appointments. If you're experiencing a dental emergency such as severe toothache, broken tooth, or knocked-out tooth, call us at (905) 876-4488 for immediate assistance."},{question:"What are Milton Dental Clinic's hours of operation?",answer:"We are open Monday 9AM-7PM, Tuesday 10AM-7PM, Wednesday 9AM-7PM, Thursday 10AM-7PM, Friday 9AM-5PM, Saturday 9AM-5PM. We are closed on Sundays."},{question:"Where is Milton Dental Clinic located?",answer:"Milton Dental Clinic is located at 342 Bronte St. S Unit 1, Milton, Ontario L9T 5B6, Canada. We serve patients from Milton, Oakville, Burlington, Georgetown, and surrounding Halton Region areas."},{question:"Does Milton Dental Clinic offer Invisalign?",answer:"Yes, Milton Dental Clinic provides Invisalign clear aligner treatment as part of our orthodontic services. Invisalign is a discreet, comfortable alternative to traditional braces for straightening teeth. Book a consultation to learn if Invisalign is right for you."},{question:"What insurance plans does Milton Dental Clinic accept?",answer:"We accept most major dental insurance plans including Sun Life, Manulife, Great-West Life, Blue Cross, Desjardins, and Green Shield Canada. Please contact our office to verify your specific coverage before your appointment."}];function r(){let e=(0,o.useScrollAnimation)(),[r,l]=(0,a.useState)(null);return(0,t.jsx)(i.default,{id:"faq",children:(0,t.jsxs)("div",{ref:e,children:[(0,t.jsxs)("div",{className:"text-center mb-12 animate-on-scroll",children:[(0,t.jsx)("h2",{className:"font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl font-bold text-dark",children:"Frequently Asked Questions"}),(0,t.jsx)("p",{className:"mt-4 text-lg text-dark/70 max-w-2xl mx-auto",children:"Find answers to common questions about our dental services in Milton."})]}),(0,t.jsx)("div",{className:"max-w-3xl mx-auto space-y-4",children:s.map((e,a)=>{let i=r===a;return(0,t.jsxs)("div",{className:`animate-on-scroll delay-${Math.min(a+1,5)} border border-gray-200 rounded-xl overflow-hidden transition-colors ${i?"bg-light":"bg-white"}`,children:[(0,t.jsxs)("button",{onClick:()=>l(i?null:a),className:"w-full flex items-center justify-between gap-4 px-6 py-5 text-left cursor-pointer","aria-expanded":i,children:[(0,t.jsx)("span",{className:"font-semibold text-dark text-sm sm:text-base",children:e.question}),(0,t.jsx)(n.ChevronDown,{className:`w-5 h-5 text-primary flex-shrink-0 transition-transform duration-200 ${i?"rotate-180":""}`})]}),(0,t.jsx)("div",{className:`overflow-hidden transition-all duration-300 ${i?"max-h-60 opacity-100":"max-h-0 opacity-0"}`,children:(0,t.jsx)("p",{className:"px-6 pb-5 text-dark/70 text-sm leading-relaxed",children:e.answer})})]},a)})})]})})}e.s(["default",()=>r])}]);