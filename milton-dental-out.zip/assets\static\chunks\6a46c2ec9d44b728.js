(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,44498,e=>{"use strict";var t=e.i(71645);function n(){let e=(0,t.useRef)(null);return(0,t.useEffect)(()=>{let t=e.current;if(!t)return;let n=t.querySelectorAll(".animate-on-scroll, .animate-slide-left, .animate-slide-right, .animate-scale-in, .animate-blur-in, .heading-line, .stagger-children"),a=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&(e.target.classList.add("animated"),a.unobserve(e.target))})},{threshold:.1,rootMargin:"0px 0px -40px 0px"});return n.forEach(e=>a.observe(e)),()=>a.disconnect()},[]),e}e.s(["useScrollAnimation",()=>n])},82217,e=>{"use strict";var t=e.i(43476),n=e.i(57688);function a({title:e,subtitle:a,bgImage:i="/miltondentalclinic/images/hero/hero-bg.webp",children:o}){return(0,t.jsxs)("section",{className:"relative w-full pt-32 pb-20 md:pt-40 md:pb-28 flex items-center justify-center overflow-hidden",children:[(0,t.jsx)(n.default,{src:i,alt:"",fill:!0,priority:!0,className:"object-cover object-right-top",sizes:"100vw"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-[#1a2836]/70"}),(0,t.jsxs)("div",{className:"relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6",children:[(0,t.jsx)("h1",{className:"hero-animate font-[family-name:var(--font-heading)] text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight tracking-tight",children:e}),a&&(0,t.jsx)("p",{className:"hero-animate-delay mt-4 text-base sm:text-lg text-white/80 max-w-2xl mx-auto",children:a}),o&&(0,t.jsx)("div",{className:"hero-animate-delay mt-8 flex flex-col sm:flex-row items-center justify-center gap-4",children:o})]})]})}e.s(["default",()=>a])},36468,e=>{"use strict";let t=[{title:"Improving ‘Community Smiles’ through patient education and health promotion",excerpt:"The first-ever Canadian Oral Health Survey (COHS), conducted from November…",slug:"improving-community-smiles",image:"/miltondentalclinic/images/blog/community-smiles.jpg",date:"2025-01-15",content:`The first-ever Canadian Oral Health Survey (COHS), conducted from November 2023 to March 2024, showed how poor oral health can impact everyday life, including eating, working, or going to school, and provides important baseline data as Canada rolls out the new Canadian Dental Care Plan.

At The Community Smiles Project, our group of dentists, public health professionals, and educators is passionate about oral health education and improving access to dental care in Toronto. We aim to equip our communities with knowledge and resources to care for their oral health through community outreach, oral health education, and oral disease prevention delivered in an accessible, culturally inclusive, and evidence-based way.

## Why Patient Education Matters

Oral health is often overlooked in broader health discussions, yet it plays a significant role in our overall well-being. Over 1 in 4 Canadians report tooth pain or avoid certain foods because of dental problems, with seniors, people without dental insurance, and those with disabilities being most affected.

Through community outreach programs, we deliver oral health workshops at schools, community events, and cultural organizations. Our approach is rooted in making information accessible and culturally inclusive, ensuring that every community member can benefit from our educational efforts.

## Our Approach

We believe that prevention is the best medicine. By educating communities about proper oral hygiene practices, nutrition's impact on dental health, and the importance of regular dental visits, we can help reduce the burden of oral disease.

Our team of young professionals is committed to improving access to oral health education through research and content creation, translating complex dental health information into easy-to-understand resources for the general public.

## Get Involved

If you're a community organization or leader interested in collaborating with The Community Smiles Project, we welcome your inquiries. Together, we can improve access to oral health education and dental services across the Greater Toronto Area.`},{title:"Oral health in pregnancy: Understanding risks, prevention, and safe dental care",excerpt:"Introduction Pregnancy is a time of a complex hormonal and…",slug:"oral-health-in-pregnancy-risks-prevention",image:"/miltondentalclinic/images/blog/oral-health-pregnancy.jpg",date:"2025-01-10",content:`## Introduction

Pregnancy is a time of complex hormonal and physiological changes that can significantly impact oral health. Understanding these risks and knowing how to maintain good dental hygiene during pregnancy is essential for both the mother's and baby's well-being.

## How Pregnancy Affects Oral Health

During pregnancy, hormonal changes\u2014particularly increased levels of estrogen and progesterone\u2014can affect the way your body responds to plaque. This can lead to several oral health concerns:

- **Pregnancy Gingivitis:** Swollen, tender gums that bleed easily, affecting up to 75% of pregnant women
- **Increased Risk of Tooth Decay:** Morning sickness and changes in eating habits can expose teeth to more acid
- **Pregnancy Tumors:** Non-cancerous growths on the gums that typically appear during the second trimester
- **Loose Teeth:** Elevated levels of progesterone and estrogen can affect the ligaments and bone supporting the teeth

## Prevention and Safe Dental Care

Maintaining good oral health during pregnancy is not only safe but highly recommended. Here are key prevention strategies:

1. **Continue Regular Dental Visits:** Routine cleanings and exams are safe during pregnancy
2. **Practice Good Oral Hygiene:** Brush twice daily with fluoride toothpaste and floss daily
3. **Manage Morning Sickness:** Rinse with baking soda and water after vomiting to neutralize acids
4. **Eat a Balanced Diet:** Limit sugary snacks and ensure adequate calcium and vitamin D intake
5. **Communicate with Your Dentist:** Inform them about your pregnancy and any medications you're taking

## When to Seek Dental Care

Don't delay dental treatment during pregnancy. If you experience tooth pain, swelling, or bleeding gums, contact your dentist promptly. Most dental procedures, including fillings and root canals, can be safely performed during pregnancy, particularly during the second trimester.

At Milton Dental Clinic, we provide safe, compassionate dental care for expectant mothers. Contact us at (905) 876-4488 to schedule your appointment.`},{title:"Oral Health During Pregnancy in Milton",excerpt:"Pregnancy is an exciting time filled with change. Along with…",slug:"oral-health-during-pregnancy-in-milton",image:"/miltondentalclinic/images/blog/pregnancy-milton.jpg",date:"2025-01-05",content:`Pregnancy is an exciting time filled with change. Along with the many physical changes happening in your body, your oral health needs extra attention too. At Milton Dental Clinic, we understand the unique dental needs of expectant mothers and are here to support you every step of the way.

## Why Oral Health Matters During Pregnancy

Your oral health is closely connected to your overall health and your baby's development. Research has shown links between gum disease and premature birth, low birth weight, and other complications. Taking care of your teeth and gums during pregnancy is one of the best things you can do for yourself and your baby.

## Common Dental Concerns During Pregnancy

Many pregnant women in Milton experience:

- **Bleeding or Swollen Gums:** Hormonal changes can make your gums more sensitive to plaque
- **Increased Cavity Risk:** Cravings for sugary foods and morning sickness can increase the risk of tooth decay
- **Dry Mouth:** Some pregnant women experience decreased saliva production
- **Enamel Erosion:** Frequent vomiting from morning sickness can erode tooth enamel

## Tips for Maintaining Oral Health

- Brush your teeth twice a day with a soft-bristled toothbrush
- Floss daily to remove plaque between teeth
- Use an antimicrobial mouth rinse if recommended by your dentist
- If you experience morning sickness, rinse your mouth with water or a baking soda solution
- Eat calcium-rich foods to support your baby's developing teeth and bones
- Stay hydrated throughout the day

## Dental Visits During Pregnancy

Regular dental check-ups are safe and important during pregnancy. The second trimester is often considered the most comfortable time for dental treatment. At Milton Dental Clinic, Dr. Zoha Anjum and our team provide gentle, pregnancy-safe dental care.

Contact us at (905) 876-4488 to schedule your prenatal dental visit at our Milton office.`},{title:"Preventive Dentistry in Milton for Healthier Smiles",excerpt:"At Milton Dental Clinic, we believe that strong smiles begin…",slug:"preventive-dentistry-in-milton",image:"/miltondentalclinic/images/blog/preventive-dentistry.jpg",date:"2024-12-20",content:`At Milton Dental Clinic, we believe that strong smiles begin with prevention. Preventive dentistry is the foundation of good oral health, helping you avoid costly and complex treatments down the road. Our team is dedicated to keeping your smile healthy through regular care and education.

## What Is Preventive Dentistry?

Preventive dentistry focuses on maintaining oral health through regular check-ups, cleanings, and good daily habits. It's about stopping dental problems before they start, rather than treating them after they develop.

## Our Preventive Services

At Milton Dental Clinic, we offer a comprehensive range of preventive services:

- **Regular Dental Exams:** Thorough examinations including TMJ and gum assessments
- **Professional Cleanings:** Scaling, polishing, and fluoride treatments
- **Oral Cancer Screenings:** Early detection of any abnormalities
- **Digital X-Rays:** Advanced imaging with minimal radiation exposure
- **Dental Sealants:** Protective coatings for cavity-prone teeth
- **Custom Mouthguards:** Protection for sports and nighttime grinding

## The Benefits of Preventive Care

Investing in preventive dentistry offers numerous benefits:

1. **Early Detection:** Catching problems when they're small and easier to treat
2. **Cost Savings:** Prevention is far less expensive than treatment
3. **Better Overall Health:** Oral health is connected to heart health, diabetes management, and more
4. **Preserved Natural Teeth:** Keep your natural smile for a lifetime
5. **Fresh Breath and Confidence:** Regular cleanings keep your smile bright

## Building Good Habits at Home

Preventive care extends beyond the dental office. We recommend:

- Brushing twice daily with fluoride toothpaste for at least two minutes
- Flossing daily to clean between teeth where your brush can't reach
- Limiting sugary and acidic foods and drinks
- Drinking plenty of water throughout the day
- Replacing your toothbrush every three to four months

## Schedule Your Preventive Visit

Don't wait for a problem to see the dentist. Schedule your preventive care appointment at Milton Dental Clinic today. Call us at (905) 876-4488 or visit our contact page to book online.`},{title:"Why Regular Dental Visits Matter for Milton Families in Milton",excerpt:"Pregnancy is an exciting time filled with change. Your mouth…",slug:"why-regular-dental-visits-matter",image:"/miltondentalclinic/images/blog/regular-visits.jpg",date:"2024-12-15",content:`Regular dental visits are one of the most important things you can do for your family's oral health. At Milton Dental Clinic, we recommend that every family member\u2014from toddlers to grandparents\u2014visit the dentist at least twice a year for check-ups and cleanings.

## Why Twice a Year?

Even if your teeth feel fine, regular dental visits are essential because:

- **Early Detection:** Many dental problems, including cavities and gum disease, don't cause pain in their early stages. Regular check-ups allow your dentist to catch issues before they become serious.
- **Professional Cleaning:** Even with excellent brushing and flossing, plaque and tartar can build up in hard-to-reach areas. Professional cleanings remove this buildup and help prevent cavities and gum disease.
- **Oral Cancer Screening:** Your dentist checks for signs of oral cancer at every visit, which is crucial for early detection and treatment.

## Benefits for Children

Starting dental visits early sets your children up for a lifetime of good oral health:

- Familiarizes them with the dental office, reducing anxiety
- Monitors the development of their teeth and jaw
- Applies preventive treatments like sealants and fluoride
- Teaches proper brushing and flossing techniques
- Identifies orthodontic needs early

## Benefits for Adults and Seniors

Regular visits are equally important as we age:

- Monitoring existing dental work (fillings, crowns, bridges)
- Managing gum disease, which becomes more common with age
- Screening for conditions linked to oral health, such as diabetes and heart disease
- Addressing dry mouth, which can be a side effect of many medications
- Maintaining dentures and other prosthetics

## Making Dental Visits a Family Affair

At Milton Dental Clinic, we welcome patients of all ages. Our team, led by Dr. Zoha Anjum, creates a comfortable and welcoming environment for the whole family. We're proud to serve Milton families with compassionate, comprehensive dental care.

Book your family's next dental visit today. Call (905) 876-4488 or visit us at 342 Bronte St. S Unit 1, Milton, ON.`},{title:"Dental Check-Up Process: What to Expect at Your Next Appointment",excerpt:"If you’re unsure about what to expect during your next…",slug:"dental-check-up-process",image:null,date:"2024-12-10",content:`If you're unsure about what to expect during your next dental visit, understanding the process can help ease any anxiety. At Milton Dental Clinic, we strive to make every appointment as comfortable and transparent as possible.

## What Happens During a Dental Check-Up?

A typical dental check-up at our Milton clinic includes several important steps:

### 1. Medical History Review

We'll review your medical history and any changes since your last visit. This includes new medications, health conditions, or concerns you may have about your oral health.

### 2. Digital X-Rays

If needed, we'll take digital X-rays to get a detailed look at your teeth, jawbone, and surrounding structures. Digital X-rays use significantly less radiation than traditional film X-rays and provide instant, high-quality images.

### 3. Comprehensive Oral Examination

Your dentist will carefully examine:

- Each tooth for signs of decay, cracks, or damage
- Your gums for signs of gum disease
- Your bite and jaw alignment
- Previous dental work (fillings, crowns, etc.)
- Soft tissues of the mouth for any abnormalities
- TMJ (jaw joint) function

### 4. Oral Cancer Screening

As part of every check-up, we screen for signs of oral cancer by examining your lips, tongue, throat, tissues, and gums.

### 5. Professional Cleaning

Our dental hygienist will:

- Remove plaque and tartar buildup
- Polish your teeth to remove surface stains
- Floss between all teeth
- Apply fluoride treatment if recommended

### 6. Discussion and Treatment Plan

After your examination, your dentist will discuss findings with you, answer any questions, and recommend any necessary treatments. We believe in empowering our patients to make informed decisions about their dental care.

## How Often Should You Visit?

We recommend visiting every six months for routine check-ups and cleanings. However, some patients may need more frequent visits depending on their oral health needs.

Schedule your next check-up at Milton Dental Clinic by calling (905) 876-4488.`},{title:"10 Signs You Need to See a Dentist ASAP",excerpt:"Are you experiencing pain, bleeding, or unusual changes in your…",slug:"10-signs-you-need-to-see-a-dentist",image:null,date:"2024-12-05",content:`Are you experiencing pain, bleeding, or unusual changes in your mouth? While some dental issues can wait for your next scheduled appointment, certain signs indicate you should see a dentist as soon as possible.

## 1. Persistent Toothache

A toothache that doesn't go away could indicate a cavity, infection, or abscess. Don't try to tough it out\u2014seek professional care to prevent the problem from worsening.

## 2. Bleeding Gums

While occasional bleeding during flossing may not be alarming, persistent bleeding gums can be a sign of gum disease. Early treatment can prevent more serious complications.

## 3. Swollen or Red Gums

Inflammation in your gums often signals gingivitis or periodontitis. Left untreated, gum disease can lead to tooth loss and has been linked to heart disease and diabetes.

## 4. Sensitivity to Hot or Cold

If drinking hot coffee or eating ice cream causes sharp pain, you may have a cavity, worn enamel, or an exposed tooth root that needs attention.

## 5. Loose or Shifting Teeth

Adult teeth should not feel loose. If you notice any movement, it could indicate advanced gum disease or bone loss.

## 6. Persistent Bad Breath

Chronic bad breath (halitosis) that doesn't improve with brushing and flossing may indicate an underlying dental or health issue.

## 7. White or Dark Spots on Teeth

White spots can be early signs of decay, while dark spots may indicate a cavity that needs treatment before it grows larger.

## 8. Jaw Pain or Clicking

Pain, popping, or clicking in your jaw could signal TMJ disorder, which can worsen without proper treatment.

## 9. Mouth Sores That Won't Heal

A sore that persists for more than two weeks should be evaluated, as it could be a sign of oral cancer or another condition requiring treatment.

## 10. Broken or Chipped Tooth

Even if it doesn't hurt, a broken or chipped tooth can worsen over time and become vulnerable to infection.

## Don't Wait\u2014We're Here to Help

If you're experiencing any of these signs, contact Milton Dental Clinic right away at (905) 876-4488. Our team provides prompt, compassionate care to address your dental concerns.`},{title:"Top 7 Benefits of a Professional Teeth Cleaning",excerpt:"Your smile is one of your most powerful assets—and keeping…",slug:"top-7-benefits-of-professional-teeth-cleaning",image:null,date:"2024-11-28",content:`Your smile is one of your most powerful assets\u2014and keeping it healthy goes beyond brushing and flossing at home. Professional teeth cleanings are a cornerstone of preventive dental care, offering benefits that extend far beyond a brighter smile.

## 1. Prevents Gum Disease

Gum disease is one of the leading causes of tooth loss in adults. Professional cleanings remove plaque and tartar buildup along and below the gum line, significantly reducing your risk of developing gingivitis and periodontitis.

## 2. Early Detection of Dental Problems

During your cleaning appointment, your dental team examines your mouth for early signs of cavities, broken fillings, gum disease, and even oral cancer. Catching these issues early means simpler, less expensive treatments.

## 3. Removes Stubborn Stains

Coffee, tea, wine, and certain foods can stain your teeth over time. Professional cleaning and polishing removes these surface stains, leaving your teeth looking brighter and cleaner.

## 4. Freshens Your Breath

Persistent bad breath is often caused by food particles and bacteria hiding in hard-to-reach places. A thorough professional cleaning eliminates these odor-causing culprits and gives you fresh, clean breath.

## 5. Protects Your Overall Health

Research has shown strong connections between oral health and overall health. Gum disease has been linked to heart disease, stroke, diabetes complications, and respiratory issues. Keeping your mouth healthy helps protect your whole body.

## 6. Saves Money in the Long Run

Prevention is always more affordable than treatment. Regular cleanings help you avoid costly procedures like root canals, crowns, and gum surgery by catching problems before they become serious.

## 7. Boosts Your Confidence

There's nothing quite like the feeling of a freshly cleaned smile. Professional cleanings give you the confidence to smile freely, knowing your teeth are healthy and looking their best.

## How Often Should You Get a Cleaning?

Most people benefit from professional cleanings every six months. However, if you have gum disease or other risk factors, your dentist may recommend more frequent visits.

## Schedule Your Cleaning Today

Ready to experience the benefits of a professional cleaning? Contact Milton Dental Clinic at (905) 876-4488 to book your appointment. Our gentle, experienced team is here to keep your smile healthy and bright.`}];e.s(["blogPosts",0,t])},48263,e=>{"use strict";var t=e.i(43476),n=e.i(57688),a=e.i(22016),i=e.i(82217),o=e.i(44498),r=e.i(36468);function s(){let e=(0,o.useScrollAnimation)();return(0,t.jsxs)("main",{children:[(0,t.jsx)(i.default,{title:"Blogs"}),(0,t.jsx)("section",{className:"py-20 md:py-28 bg-[#1A2332]",children:(0,t.jsx)("div",{ref:e,className:"max-w-6xl mx-auto px-4 sm:px-6",children:(0,t.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",children:r.blogPosts.map((e,i)=>(0,t.jsxs)("div",{className:`animate-on-scroll delay-${i%3+1} group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 flex flex-col`,children:[(0,t.jsx)("div",{className:"relative h-52 overflow-hidden",children:e.image?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.default,{src:e.image,alt:e.title,fill:!0,className:"object-cover transition-transform duration-300 group-hover:scale-105",sizes:"(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 33vw"}),(0,t.jsx)("div",{className:"absolute inset-0 bg-gradient-to-t from-primary/40 to-transparent"})]}):(0,t.jsx)("div",{className:"w-full h-full bg-gradient-to-br from-[#0075C9]/15 to-[#0075C9]/5 flex items-center justify-center",children:(0,t.jsx)("svg",{className:"w-16 h-16 text-[#0075C9]/25",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:1,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5M6 7.5h3v3H6V7.5z"})})})}),(0,t.jsxs)("div",{className:"p-6 flex flex-col flex-1",children:[(0,t.jsx)("h3",{className:"font-[family-name:var(--font-heading)] text-lg font-bold leading-snug mb-3",children:(0,t.jsx)(a.default,{href:`/blog/${e.slug}`,className:"text-primary hover:text-primary/80 transition-colors",children:e.title})}),(0,t.jsx)("p",{className:"text-dark/60 text-sm leading-relaxed mb-5 flex-1",children:e.excerpt}),(0,t.jsxs)(a.default,{href:`/blog/${e.slug}`,className:"inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary/80 transition-colors",children:["Learn more",(0,t.jsx)("svg",{className:"w-4 h-4 transition-transform group-hover:translate-x-0.5",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",strokeWidth:2,children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3"})})]})]})]},e.slug))})})})]})}e.s(["default",()=>s])}]);